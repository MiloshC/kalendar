
package dataPull;


public class UserInfoPull {
     final String USER_INFO = "SELECT FROM ";
}
