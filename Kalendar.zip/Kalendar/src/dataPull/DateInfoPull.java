
package dataPull;


public class DateInfoPull {
    final String DATE_INFO = "SELECT FROM ";
}
