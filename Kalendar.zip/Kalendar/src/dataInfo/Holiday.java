
package dataInfo;

import java.sql.Timestamp;


public class Holiday {
    private Timestamp holiday;

    public Timestamp getHoliday() {
        return holiday;
    }

    public void setHoliday(Timestamp holiday) {
        this.holiday = holiday;
    }
    
}
